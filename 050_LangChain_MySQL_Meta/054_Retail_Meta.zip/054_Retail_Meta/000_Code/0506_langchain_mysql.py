from langchain.llms import GooglePalm

# (1) Google Palm LLM & API key setup
#api_key = 'AIzaSyDlXYnP2xNNa0DNa7dPN89u2L4IuAchEg4'
#llm = GooglePalm(google_api_key=api_key, temperature=0.2)

print('(1) Google Palm LLM & API key setup...')
import os
import sys
sys.path.append(os.path.abspath("/home/peter/"))
from secret_key import *
print('googleapi_key:', googleapi_key)

# (3) Test Google's llm()
from langchain.llms import GooglePalm
llm = GooglePalm(google_api_key=googleapi_key, temperature=0.2)
print('llm:', llm) # llm: GooglePalm
print()
q1 = "write a poem on my love for dosa"
a1 = llm(q1)
print('q1:', q1)
print('a1:')
print(a1)

# (4) Connect with database ands ask some basic quesiotns
from langchain.utilities import SQLDatabase
db_user = "root"
db_password = "root"
db_host = "localhost"
db_name = "atliq_tshirts"
# URL syntax: "mysql+pymysql://root:root@localhost/{db_name}"
print()
url_name = "mysql+pymysql://"+db_user+":"+ db_password+"@"+db_host + "/" + db_name
print('url_name = "mysql+pymysql://"+db_user+":"+ db_password+"@"+db_host + "/" + db_name:')
print('url_name:', url_name)
#db = SQLDatabase.from_uri(f"mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}",sample_rows_in_table_info=3)
print("db = SQLDatabase.from_uri(url_name,sample_rows_in_table_info=3) ...")
db = SQLDatabase.from_uri(url_name,sample_rows_in_table_info=3)
print()
print("db.table_info:")
print(db.table_info)

# (5) Language Chain by Experimental Modules
from langchain_experimental.sql import SQLDatabaseChain
db_chain = SQLDatabaseChain.from_llm(llm, db, verbose=True)
qns1_1 = db_chain("Sum of t-shirts do we have left for nike in extra small size?")
print(); print()
print("qns1_1:")
print(qns1_1)

qns1_2 = db_chain("Sum of t-shirts do we have left for nike in extra small size and white color?")
print(); print()
print("qns1_2:")
print(qns1_2)

qns2_1 = db_chain.run("What is the total price in stock of t-shirts in small size")
print(); print()
print("qns2_1:")
print(qns2_1)

qns2_2 = db_chain.run("SELECT SUM(price*stock_quantity) FROM t_shirts WHERE size = 'S'")
print(); print()
print("qns2_2:")
print(qns2_2)

# database does not have start/end date.
#qns3_1 = db_chain.run("If we have to sell all the Levi’s T-shirts from 2011 to 2022 with discounts applied. How much revenue our store will generate (post discounts)?")
#print(); print()
#print("qns3_1:")
#print(qns3_1)
#print()

qns3_2 = db_chain.run("Sum of all the Levi’s T-shirts with discounts?")
print(); print()
print("qns3_2:")
print(qns3_2)
print()

qns4 = db_chain.run("SELECT SUM(price*stock_quantity) FROM t_shirts WHERE brand = 'levi'")
print(); print()
print("qns4:")
print(qns4)
print()

qns5_1 = db_chain.run("How many white color Leve's t-shirts we have available?")
print(); print()
print("qns5_1:")
print(qns5_1)
print()

qns5_2 = db_chain.run("Sum of white color Leve's t-shirts we have available?")
print(); print()
print("qns5_2:")
print(qns5_2)
print()