import sys
import os
sys.path.append(os.path.abspath("/home/peter"))

from secret_key import *
print ('openapi_key:', openapi_key)
