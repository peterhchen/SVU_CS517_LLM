import os
import sys
sys.path.append(os.path.abspath("/home/peter/"))
from secret_key import *
#print('sys.path:', sys.path)
#print('openapi_key:', openapi_key)
print('googleapi_key:', googleapi_key)
#print('replicateapi_key:', replicateapi_key)
#os.environ["REPLICATE_API_TOKEN"] = replicateapi_key
#os.environ['API_KEY'] = googleapi_key

# (1) Basic working of Google Palm LLM in LangChain
print('(1) Basic working of Google Palm LLM in LangChain...')
from langchain.llms import GooglePalm
api_key = googleapi_key     # get this free api key from https://makersuite.google.com/

llm = GooglePalm(google_api_key=api_key, temperature=0.1)

poem = llm("Write a 4 line poem of my love for samosa")
print('poem:', poem)

essay = llm("write email requesting refund for electronic item")
print('essay:', essay)

# (2) import langchain
print('(2) import langchain...')
from langchain.chains import RetrievalQA
from langchain.embeddings import GooglePalmEmbeddings
from langchain.llms import GooglePalm

# (3) Now let's load data from Codebasics FAQ csv file
print("(3) Now let's load data from Codebasics FAQ csv file...")
from langchain.document_loaders.csv_loader import CSVLoader

loader = CSVLoader(file_path='./codebasics_faqs.csv', source_column="prompt")

# (4) Store the loaded data in the 'data' variable
print("(4) Store the loaded data in the 'data' variable...")
data = loader.load()

# (5) Hugging Face Embeddings
print("(5) Hugging Face Embeddings...")
from langchain.embeddings import HuggingFaceInstructEmbeddings

# Initialize instructor embeddings using the Hugging Face model
print("Initialize instructor embeddings using the Hugging Face model...")
instructor_embeddings = HuggingFaceInstructEmbeddings(model_name="hkunlp/instructor-large")

e = instructor_embeddings.embed_query("What is your refund policy?")
print('len(e):', len(e))
print('e[:5]:', e[:5])

# (6) Vector store using FAISS
print("(6) Vector store using FAISS...")
from langchain.vectorstores import FAISS

# (7) Create a FAISS instance for vector database from 'data'
print("(7) Create a FAISS instance for vector database from 'data'...")
vectordb = FAISS.from_documents(documents=data,
                                 embedding=instructor_embeddings)

# (8) Create a retriever for querying the vector database
print("(8) Create a retriever for querying the vector database...")
retriever = vectordb.as_retriever(score_threshold = 0.7)
rdocs = retriever.get_relevant_documents("how about job placement support?")
print('rdocs:', rdocs)

# google_palm_embeddings = GooglePalmEmbeddings(google_api_key=api_key)

# from langchain.vectorstores import Chroma
# vectordb = Chroma.from_documents(data,
#                            embedding=google_palm_embeddings,
#                            persist_directory='./chromadb')
# vectordb.persist()

# (9) Create RetrievalQA chain along with prompt template 
print("(9) Create RetrievalQA chain along with prompt template...")
from langchain.prompts import PromptTemplate
print("prompt_template ...")
prompt_template = """Given the following context and a question, generate an answer based on this context only.
In the answer try to provide as much text as possible from "response" section in the source document context without making much changes.
If the answer is not found in the context, kindly state "I don't know." Don't try to make up an answer.

CONTEXT: {context}

QUESTION: {question}"""

print("PROMPT ...")
PROMPT = PromptTemplate(
    template=prompt_template, input_variables=["context", "question"]
)
chain_type_kwargs = {"prompt": PROMPT}

print("RetrievalQA...")
from langchain.chains import RetrievalQA

chain = RetrievalQA.from_chain_type(llm=llm,
                            chain_type="stuff",
                            retriever=retriever,
                            input_key="query",
                            return_source_documents=True,
                            chain_type_kwargs=chain_type_kwargs)

# (10) We are all set. Let's ask some questions now
print("(10) We are all set. Let's ask some questions now...")
qa1 = chain('Do you provide job assistance and also do you provide job gurantee?')
print('************qa1************:')
print(qa1)
print()
qa2 = chain("Do you guys provide internship and also do you offer EMI payments?")
print('************qa2************:')
print(qa2)
print()
qa3 = chain("do you have javascript course?")
print('************qa3************:')
print(qa3)
print()
qa4 = chain("Do you have plans to launch blockchain course in future?")
print('************qa4************:')
print(qa4)
print()
qa5 = chain("should I learn power bi or tableau?")
print('************qa5************:')
print(qa5)